package com.tech.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.tech.entities.User;

public class Userdao {

	private Connection conn;

	public Userdao(Connection conn) {
		super();
		this.conn = conn;
	}

	public boolean saveUser(User user) {

		String Equery = "select * from data_handling where email =?";
		String email = user.getEmail();
		System.out.println("email :::::::::::" + email);
		ResultSet s;
		try {
			PreparedStatement Pst = conn.prepareStatement(Equery);
			Pst.setString(1, email);
			s = Pst.executeQuery();
			System.out.println(s.toString() + "value of s:::");

			if (s.next()) {
				System.out.println("Email alraedy avl");
				

				return false;
			} else {

				String sql = "INSERT INTO data_handling (firstname, lastname, email, password,address,gender,hobbies,Profile_pic) values (?, ?, ?, ?,?, ?, ?,?)";
System.out.println(user.getFirstname());
				PreparedStatement statement = conn.prepareStatement(sql);
				statement.setString(1, user.getFirstname());
				statement.setString(2, user.getLastname());
				statement.setString(3, user.getEmail());
				// String file = fileSaveDir.getAbsolutePath() + File.separator + fileName;
				statement.setString(4, user.getPassword());
				statement.setString(5, user.getAddress());
				statement.setString(6, user.getGender());
				statement.setString(7, user.getHobbies());
				statement.setString(8, user.getProfilePic());

				int row = statement.executeUpdate();
				if (row > 0) {
					System.out.println("File uploaded and saved into database");
					return true;
				}
			}

		} catch (SQLException e) {
			System.out.println("ERROR: " + e.getMessage());
			e.printStackTrace();
		}
		return false;
	}
	
	public User userGetById(int userid) throws ClassNotFoundException {
		User u = null;

		try {
			String sql = "select * from data_handling where userid =?";

			PreparedStatement ps = conn.prepareStatement(sql);
			ps.setInt(1, userid);
			/* System.out.println(ps); */
			ResultSet rs = ps.executeQuery();
			while (rs.next()) {
				u = new User();
				u.setUserid(rs.getInt(1));
				u.setFirstname(rs.getString(2));
				u.setLastname(rs.getString(3));
				u.setEmail((rs.getString(4)));
				u.setPassword((rs.getString(5)));
				u.setAddress(rs.getString(6));
				
				System.out.println(u.getAddress());
				
				u.setGender((rs.getString(7)));;
				u.setHobbies((rs.getString(8)));
				u.setProfilePic(rs.getString(9));

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return u;
	}
	
	public boolean updateuser(User user) {
		boolean f = false;

		try {
			
			String sql = "UPDATE  data_handling SET firstname=?, lastname=?, email=?, password=?,address=?,gender=?,hobbies=?,Profile_pic=? where userid = ?;";

			PreparedStatement statement = conn.prepareStatement(sql);
			statement.setString(1, user.getFirstname());
			statement.setString(2, user.getLastname());
			// String file = fileSaveDir.getAbsolutePath() + File.separator + fileName;
			statement.setString(3, user.getEmail());
			 statement.setString(4, user.getPassword());
			statement.setString(5, user.getAddress());
		
			statement.setString(6, user.getGender());
			statement.setString(7, user.getHobbies());
			statement.setString(8, user.getProfilePic());
			statement.setInt(9, user.getUserid());
			int i = statement.executeUpdate();

			if (i == 1) {
				f = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return f;
	}
	
	public boolean updateuser1(User user) {
		boolean f = false;

		try {
			
			String sql = "UPDATE  data_handling SET firstname=?, lastname=?, email=?, password=?,address=?,gender=?,hobbies=? where userid = ?;";

			PreparedStatement statement = conn.prepareStatement(sql);
			statement.setString(1, user.getFirstname());
			statement.setString(2, user.getLastname());
			// String file = fileSaveDir.getAbsolutePath() + File.separator + fileName;
			statement.setString(3, user.getEmail());
			 statement.setString(4, user.getPassword());
			statement.setString(5, user.getAddress());
		
			statement.setString(6, user.getGender());
			statement.setString(7, user.getHobbies());
			/* statement.setString(8, user.getProfilePic()); */
			statement.setInt(8, user.getUserid());
			int i = statement.executeUpdate();

			if (i == 1) {
				f = true;
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return f;
	}

	public boolean deleteuser(int userid) {
		boolean f = false;
		try {
			String sql_delete = "delete from data_handling where userid = ?";
			
			PreparedStatement ps = conn.prepareStatement(sql_delete);
			ps.setInt(1, userid);
			System.out.println("delelte dao userid ="+ userid);
			int i = ps.executeUpdate();
			if (i == 1) {
				f = true;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return f;
	}
	

}
