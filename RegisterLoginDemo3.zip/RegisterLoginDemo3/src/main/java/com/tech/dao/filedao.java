
package com.tech.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.tech.entities.Fileup;
import com.tech.entities.User;

public class filedao {
	private Connection conn;

	public filedao(Connection conn) {
		super();
		this.conn = conn;
	}

	public boolean saveFile(Fileup Fileup) {

		/*
		 * String Equery = "select * from filedatails where userid =?"; int userid =
		 * Fileup.getUserid();
		 * 
		 * System.out.println("userid :::::::::::" + userid); ResultSet s; try {
		 * PreparedStatement Pst = conn.prepareStatement(Equery); Pst.setInt(1, userid);
		 * s = Pst.executeQuery(); System.out.println(s + "value of s:::");
		 */
try {
		String sql = "INSERT INTO filedatails (userid, uploadeddate,  filename ) values (?, ?, ?)";
		System.out.println(Fileup.getUserid());
		PreparedStatement statement = conn.prepareStatement(sql);
		statement.setInt(1, Fileup.getUserid());
		statement.setString(2, Fileup.getUploadeddate());
		statement.setString(3, Fileup.getFilename());
		// String file = fileSaveDir.getAbsolutePath() + File.separator + fileName;
		// statement.setString(4, user.getPassword());
		/*
		 * statement.setString(5, user.getAddress()); statement.setString(6,
		 * user.getGender()); statement.setString(7, user.getHobbies());
		 */

		int row = statement.executeUpdate();
		if (row > 0) {
			System.out.println("File uploaded and saved into database");
			return true;
		}
	}
	catch(SQLException e){
			System.out.println("ERROR: " + e.getMessage());
			e.printStackTrace();
		}return false;

}
	
	public boolean deleteuser(int fileid) {
		boolean f = false;
		try {
			String sql_delete = "delete from filedatails where fileid = ?";
			PreparedStatement ps = conn.prepareStatement(sql_delete);
			ps.setInt(1, fileid);

			int i = ps.executeUpdate();
			if (i == 1) {
				f = true;
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return f;
	}
	}
