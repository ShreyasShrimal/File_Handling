package com.tech.helper;

public class upload {
	private static final String UPLOAD_DIR = "resource";
public void fileupload() {
	
}
}
