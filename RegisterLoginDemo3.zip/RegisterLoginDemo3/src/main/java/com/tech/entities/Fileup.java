package com.tech.entities;

import java.sql.Connection;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Fileup {
private int fileid;
private int userid;
private String uploadeddate;
private String filename;
public int getFileid() {
	return fileid;
}
public void setFileid(int fileid) {
	this.fileid = fileid;
}
public int getUserid() {
	return userid;
}
public void setUserid(int userid) {
	this.userid = userid;
}
public String getUploadeddate() {
	return uploadeddate;
}
public void setUploadeddate(String uploadeddate) {
	this.uploadeddate = UploadedDate();
}
public String getFilename() {
	return filename;
}
public void setFilename(String filename) {
	this.filename = filename;
}
public Fileup(int fileid, int userid, String uploadeddate, String filename) {
	super();
	this.fileid = fileid;
	this.userid = userid;
	this.uploadeddate = uploadeddate;
	this.filename = filename;
}
public Fileup(int userid, String uploadeddate, String filename) {
	super();
	this.userid = userid;
	this.uploadeddate = uploadeddate;
	this.filename = filename;
}



public static String Datefmt() {
	DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
	LocalDateTime now = LocalDateTime.now();
	//System.out.println(dtf.format(now).replace("/", "_"));
	return dtf.format(now);
}
 public  static String UploadedDate() {
        DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");  
        LocalDateTime now = LocalDateTime.now();  
        System.out.println(dtf.format(now));
        return dtf.format(now);
        }

}



