package com.tech.entities;

public class User {
	
	private int userid;
	private String firstname;
	private String lastname;
	private String email;
	private String password;
	private String address;
	private String ProfilePic;
	public String getProfilePic() {
		return ProfilePic;
	}
	public void setProfilePic(String profilePic) {
		ProfilePic = profilePic;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	private String gender;
	private String hobbies;
	public int getUserid() {
		return userid;
	}
	public void setUserid(int userid) {
		this.userid = userid;
	}
	public String getFirstname() {
		return firstname;
	}
	public void setFirstname(String firstname) {
		this.firstname = firstname;
	}
	public String getLastname() {
		return lastname;
	}
	public void setLastname(String lastname) {
		this.lastname = lastname;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getHobbies() {
		return hobbies;
	}
	public void setHobbies(String hobbies) {
		this.hobbies = hobbies;
	}
	
	public User(int userid, String firstname, String lastname, String email, String password,String address, String gender,
			String hobbies,String ProfilePic) {
		super();
		this.userid = userid;
		this.firstname = firstname;
		this.lastname = lastname;
		this.email = email;
		
		this.password = password;
		this.address=address;
		this.gender = gender;
		this.hobbies = hobbies;
		this.ProfilePic=ProfilePic;
	}

	public User(int userid, String firstname, String lastname, String email, String password,String address, String gender,
			String hobbies) {
		super();
		this.userid = userid;
		this.firstname = firstname;
		this.lastname = lastname;
		this.email = email;
		
		this.password = password;
		this.address=address;
		this.gender = gender;
		this.hobbies = hobbies;
		
	}
	public User(String firstname, String lastname, String email, String password,String address, String gender, String hobbies,String ProfilePic) {
		super();
		this.firstname = firstname;
		this.lastname = lastname;
		this.email = email;
		
		this.password = password;
		this.address=address;
		this.gender = gender;
		this.hobbies = hobbies;
		this.ProfilePic=ProfilePic;
	}
	public User() {
		super();
	}

	
	

}
