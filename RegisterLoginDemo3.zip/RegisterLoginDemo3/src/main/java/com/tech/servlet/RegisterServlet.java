package com.tech.servlet;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import com.tech.dao.Userdao;
import com.tech.entities.Fileup;
import com.tech.entities.User;
import com.tech.helper.Dbconection;

@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 10, // 10 MB //
		maxFileSize = 1024 * 1024 * 50, // 50 MB
		maxRequestSize = 1024 * 1024 * 100) // 100 MB

@WebServlet("/RegisterServlet")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	/* private static final String UPLOAD_DIR = "images"; */

	public RegisterServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String firstname = request.getParameter("firstname");
		System.out.println(firstname);
		String lastname = request.getParameter("lastname");
		System.out.println(lastname);
		String email = request.getParameter("email");
		System.out.println(email);
		String address = request.getParameter("address");
		System.out.println(address);
		String password = request.getParameter("password");
		System.out.println(password);
		String gender = request.getParameter("gender");
		System.out.println(gender);
		/*
		 * String hobbies = request.getParameter("hobbies");
		 * System.out.println(hobbies);
		 */
		String[] hobbie = request.getParameterValues("hobbies");
		String hobbies = "";
		for (int i = 0; i < hobbie.length; i++) {
			hobbies += hobbie[i] + ",";
		}
		System.out.println(hobbies);
		/* String ProfilePic = request.getParameter("profile_photo"); */

		/*
		 * String applicationPath = request.getServletContext().getRealPath("");
		 * 
		 * String uploadFilePath = applicationPath + File.separator + UPLOAD_DIR;
		 * 
		 * File fileSaveDir = new File(uploadFilePath); if (!fileSaveDir.exists()) {
		 * fileSaveDir.mkdirs(); }
		 * 
		 * System.out.println("Upload File Directory=" + fileSaveDir.getAbsolutePath());
		 * // System.out.println();
		 */
		/* String fileName = getFileName(file); */
		/*
		 * String extension = ""; int index = fileName.lastIndexOf('.'); if (index > 0)
		 * {
		 *//*
			 * extension = fileName.substring(index + 1);
			 * System.out.println("File extension is " + extension);
			 */
		String dformat = Fileup.Datefmt();
		// System.out.println("File.separator =>" + File.separator);
		/* fileName = dformat + fileName; */
		/* System.out.println("Filename with date :" + fileName); */
		/*
		 * String Filenamewithpath = uploadFilePath + File.separator + fileName;
		 * file.write(uploadFilePath + File.separator + fileName);
		 */

		/*
		 * Part file = request.getPart("profile_photo"); System.out.println(file);
		 * String profilepic = file.getSubmittedFileName(); profilepic
		 * =dformat+profilepic; System.out.println(profilepic);
		 * 
		 * String uploadpath =
		 * "C:/Users/shrim/Desktop/WorkSpace/RegisterLoginDemo2/src/main/webapp/WEB-INF/images/"
		 * + profilepic;
		 * 
		 * System.out.println("image upload path:" + uploadpath);
		 * 
		 * try { System.out.println("in try"); FileOutputStream fos = new
		 * FileOutputStream(uploadpath); InputStream ios = file.getInputStream(); byte[]
		 * data = new byte[ios.available()]; ios.read(); fos.write(data); fos.close();
		 * 
		 * } catch (Exception e) { e.printStackTrace(); }
		 */

		System.out.println("In do post method of Add Image servlet.");
		Part file = request.getPart("profile_photo");

		String imageFileName = file.getSubmittedFileName(); // get selected image file name

		imageFileName = dformat + imageFileName;
		System.out.println("Selected Image File Name : " + imageFileName);

		String uploadPath = "C:/Users/shrim/Desktop/WorkSpace/RegisterLoginDemo2/src/main/webapp/profile_pic/"
				+ imageFileName; // upload path where we have to upload our actual image
		System.out.println("Upload Path : " + uploadPath);

		// Uploading our selected image into the images folder

		try {

			FileOutputStream fos = new FileOutputStream(uploadPath);
			InputStream is = file.getInputStream();

			byte[] data = new byte[is.available()];
			is.read(data);
			fos.write(data);
			fos.close();

		}

		catch (Exception e) {
			e.printStackTrace();
		}

		User u = new User(firstname, lastname, email, password, address, gender, hobbies, imageFileName);
		u.setProfilePic(imageFileName);
		Userdao dao = new Userdao(Dbconection.getconnect());
		if (dao.saveUser(u) == true) {
			System.out.println("done");
			response.sendRedirect("AllEmpdata.jsp");
		} else {

			PrintWriter out = response.getWriter();
			/*
			 * RequestDispatcher rq = request.getRequestDispatcher("Index.jsp");
			 * rq.forward(request, response);
			 */
			out.println("<script>alert('Email already exists ')</script>");
			/* request.getRequestDispatcher("userUpload.jsp") */
			/* response.sendRedirect("Index.jsp"); */
		}

	}

	private String getFileName(Part part) {
		// System.out.println("part =>" + part);
		String contentDisp = part.getHeader("content-disposition");
		System.out.println("content-disposition header= " + contentDisp);
		String[] tokens = contentDisp.split(";");
		for (String token : tokens) {
			System.out.println("token.trim()" + token.trim());
			if (token.trim().startsWith("filename")) {

				return token.substring(token.indexOf("=") + 2, token.length() - 1);
			}
		}
		return "";

	}
}
