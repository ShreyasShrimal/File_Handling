package com.tech.servlet;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.Part;

import com.tech.dao.Userdao;
import com.tech.entities.Fileup;
import com.tech.entities.User;
import com.tech.helper.Dbconection;

@MultipartConfig(fileSizeThreshold = 1024 * 1024 * 10, // 10 MB //
		maxFileSize = 1024 * 1024 * 50, // 50 MB
		maxRequestSize = 1024 * 1024 * 100) // 100 MB
@WebServlet("/UpdateServlet")
public class UpdateServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse resp) throws ServletException, IOException {

		System.out.println("hello nice to meet you");
		String firstname = request.getParameter("firstname");
		System.out.println(firstname);
		String lastname = request.getParameter("lastname");
		System.out.println(lastname);
		String email = request.getParameter("email");
		System.out.println(email);
		String address = request.getParameter("address");
		System.out.println(address);
		String password = request.getParameter("password");
		System.out.println(password);
		String gender = request.getParameter("gender");
		System.out.println(gender);
		/*
		 * String hobbies = request.getParameter("hobbies");
		 * System.out.println(hobbies);
		 */
		String[] hobbie = request.getParameterValues("hobbies");
		String hobbies = "";
		for (int i = 0; i < hobbie.length; i++) {
			hobbies += hobbie[i] + ",";
		}
		System.out.println(hobbies);

		/* String date = User.UploadedDate(); */
		/*
		 * String file = request.getParameter("profile"); System.out.println(file);
		 */

		String dformat = Fileup.Datefmt();

		System.out.println("In do post method of Add Image servlet.");
		Part file = request.getPart("profile");

		String imageFileName = file.getSubmittedFileName();
		System.out.println("This is new image" + imageFileName);
		
		HttpSession se = request.getSession();
		String profile = (String) se.getAttribute("profile");
		String status1 = (String) se.getAttribute("user");
		int userid;
		if (status1.equalsIgnoreCase("admin")) {
			userid = Integer.parseInt(request.getParameter("userid"));
			System.out.println("in if userid :" + userid);
		} else {
			userid = (Integer) se.getAttribute("userid");
			System.out.println("in else userid :" + userid);
		}

		if (imageFileName == "") {
			HttpSession se2 = request.getSession();
			/* int userid = (Integer) se2.getAttribute("userid"); */
			System.out.println(userid + "nb");
			System.out.println("Is null " + imageFileName);
			User u = new User(userid, firstname, lastname, email, password, address, gender, hobbies);
			/* System.out.println(u.toString()); */

			try {
				Userdao u1 = new Userdao(Dbconection.getconnect());
				HttpSession session = request.getSession();
				boolean f = u1.updateuser1(u);
				System.out.println("h1");
				if (f) {
					System.out.println("in if");
					session.setAttribute("succMsg", "user Updated sucsessfully...");
					resp.sendRedirect("Profilecard.jsp?userid="+userid);
				} else {
					session.setAttribute("errorMsg", "Somthing wrong on server...");
					resp.sendRedirect("Profilecard.jsp");
				}

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		else {
			imageFileName = dformat + imageFileName;

			System.out.println("Selected Image File Name : " + imageFileName);

			String uploadPath = "C:/Users/shrim/Desktop/WorkSpace/RegisterLoginDemo2/src/main/webapp/profile_pic/"
					+ imageFileName; // upload path where we have to upload our actual image
			System.out.println("Upload Path : " + uploadPath);

			// Uploading our selected image into the images folder

			try {

				FileOutputStream fos = new FileOutputStream(uploadPath);
				InputStream is = file.getInputStream();

				byte[] data = new byte[is.available()];
				is.read(data);
				fos.write(data);
				fos.close();

			}

			catch (Exception e) {
				e.printStackTrace();
			}

//		HttpSession se2 = request.getSession();
//		int userid = (Integer) se2.getAttribute("userid");
//		System.out.println(userid +"nb");
			/*
			 * HttpSession ht=req.getSession(); String fid=(String) ht.getAttribute("id");
			 * String tid=(String) ht.getAttribute("mid"); System.out.println(fid);
			 * System.out.println(tid);
			 */
			/* int id=req.getParameter("file_id"); */
//		String file=req.getParameter("Id proof");
//		System.out.println(file);
			User u = new User(userid, firstname, lastname, email, password, address, gender, hobbies, imageFileName);
			/* System.out.println(u.toString()); */

			try {
				Userdao u1 = new Userdao(Dbconection.getconnect());
				HttpSession session = request.getSession();
				boolean f = u1.updateuser(u);
				if (f) {

					session.setAttribute("succMsg", "user Updated sucsessfully...");
					resp.sendRedirect("Profilecard.jsp");
				} else {
					session.setAttribute("errorMsg", "Somthing wrong on server...");
					resp.sendRedirect("Profilecard.jsp");

				}

			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
