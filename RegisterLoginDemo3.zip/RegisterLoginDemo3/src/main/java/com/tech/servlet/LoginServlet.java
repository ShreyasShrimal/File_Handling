package com.tech.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tech.helper.Dbconection;

@WebServlet("/LoginServlet")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public LoginServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
//		// TODO Auto-generated method stub
//		String uname =request.getParameter("ename") ;
//		String Password =request.getParameter("pass") ;
		PrintWriter out = response.getWriter();

		String Email = request.getParameter("email");
		System.out.println("This from client"+Email);
		String password = request.getParameter("password");
		System.out.println(password);
		HttpSession hs = request.getSession();
		hs.setAttribute("Email", Email);


		Connection conn = Dbconection.getconnect();
		
		boolean f = false;

		try {
			PreparedStatement ps = conn.prepareStatement("SELECT * FROM data_handling where email=? and password=?");
			ResultSet rs;
			
			  ps.setString(1,Email);
			    ps.setString(2,password);
			    rs = ps.executeQuery();
			System.out.println(Email + "+++");
	        HttpSession session1=request.getSession();  
	        session1.setAttribute("Email",Email); 
	        String Emp="Employee";
			/* session1.setAttribute("user","Employee"); */ 
	         
			System.out.println("password " + password);
		
			if (rs.next()) {
//				email = rs.getString("email_Id");
//				System.out.println("email :" + email);
//				Pw = rs.getString("password");
//				System.out.println("pass :" + Pw);
				//if ((Email.equals(email)) && (password.equals(Pw))) {
					// System.out.println("ok");
				
				session1.setAttribute("userid",rs.getInt("userid"));
				session1.setAttribute("user",Emp); 
				session1.setAttribute("loginstatus",true);
					f = true;
					System.out.println(f);
					/* response.sendRedirect("Datatable.jsp"); */
				
					HttpSession session = request.getSession();
					
					
					if (f) {

						session.setAttribute("succMsg", "Login sucsessfully...");
						response.sendRedirect("Datatable.jsp");
					} else {
						session.setAttribute("errorMsg", "Somthing wrong on server...");
						response.sendRedirect("Datatable.jsp");

					}
					//RequestDispatcher Re = request.getRequestDispatcher("Datatable.jsp");
					//Re.forward(request, response);
					//rs.close();
			}
				// rs.close();
			//	if ((!Email.equals(email)) || (!password.equals(Pw))) {
					// out.println("Please enter valid pw");
//					out.println("<script>alert('Invalid username and pw')</script>");
//					RequestDispatcher Re1 = request.getRequestDispatcher("login.html");
//
//					Re1.include(request, response);
//					return;
//				}
				// rs.close();
//				if (((!Email.equals(email)) && (!password.equals(Pw)))) {
			else {
				
				RequestDispatcher Re = request.getRequestDispatcher("login.jsp");
				out.println("<script>alert('Please enter valid eamil id and password')</script>");
				Re.include(request, response);
				// response.sendRedirect("userUpload.jsp");
				f = false;
				
				/*
				 * out.
				 * println("<script>alert('Please enter valid eamil id and password')</script>"
				 * ); RequestDispatcher Re = request.getRequestDispatcher("Login.jsp"); out.
				 * println("<script>alert('Please enter valid eamil id and password')</script>"
				 * ); Re.include(request, response); // response.sendRedirect("userUpload.jsp");
				 * f = false;
				 */
			}

//				   
//					// out.println("<h2>User not availabe please resigter first</h2>");
//					
//					System.out.println(f);
//					System.out.println();
////					
//					//out.println("<script type=\"text/javascript\">");
//					// out.println("alert('Please select valid file format!');");
//					out.println("<script>alert('User is not availabe please resigter first')</script>");
//					//out.println("location='Upload.jsp';");
//					//out.println("</script>");
//
//					RequestDispatcher Re = request.getRequestDispatcher("userUpload.jsp");
//
//					Re.include(request, response);
//					//response.sendRedirect("userUpload.jsp");
//					f=false;
//				}
//				
		
//			if (f==false) {
//				return;
//			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

//		
//		
//			out.println(" Login failed");
//			out.println(" Please enter valid Id and pw");
//	RequestDispatcher Re = request.getRequestDispatcher("login.html");
//			Re.include(request, response);
//		}
//	}

	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doGet(request, response);
	}

}
