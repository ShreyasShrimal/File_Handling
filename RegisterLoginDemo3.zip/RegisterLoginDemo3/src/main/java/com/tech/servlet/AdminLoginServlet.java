package com.tech.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tech.helper.Dbconection;


@WebServlet("/AdminLoginServlet")
public class AdminLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
    public AdminLoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		
		PrintWriter out = response.getWriter();

		String Email = request.getParameter("email");
		System.out.println("This from client"+Email);
		String password = request.getParameter("password");
		System.out.println(password);
		HttpSession hs = request.getSession();
		hs.setAttribute("Email", Email);
		hs.setAttribute("user", "admin");
String adminemail ="admin@gmail.com";
String adminpassword ="admin";		
		
		boolean f = false;

	
		
			if (Email.equals(adminemail)&&password.equals(adminpassword)) {
				
				   HttpSession session = request.getSession();
				   session.setAttribute("loginstatus",true);	
				session.setAttribute("f",true);
					f = true;
					System.out.println(f);
					
				
					
					
					
					if (f) {

						session.setAttribute("succMsg", "Login sucsessfully...");
						response.sendRedirect("AllEmpdata.jsp");
					} 
					
			}
			
			else {
					RequestDispatcher Re = request.getRequestDispatcher("adminlogin.jsp");
					out.println("<script>alert('Please enter valid eamil id and password')</script>");
					Re.include(request, response);
					// response.sendRedirect("userUpload.jsp");
					f = false;
			}
	
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
