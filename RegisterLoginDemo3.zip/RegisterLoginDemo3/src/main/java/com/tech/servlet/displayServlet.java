package com.tech.servlet;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.ServletOutputStream;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tech.dao.Userdao;
import com.tech.entities.User;
import com.tech.helper.Dbconection;

@WebServlet("/display")
public class displayServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public displayServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		/*
		 * try{ String fileName = request.getParameter("image"); FileInputStream fis =
		 * new FileInputStream(new File("d:\\"+fileName)); BufferedInputStream bis = new
		 * BufferedInputStream(fis); response.setContentType(contentType);
		 * BufferedOutputStream output = new
		 * BufferedOutputStream(response.getOutputStream()); for (int data; (data =
		 * bis.read()) > -1;) { output.write(data); } } catch(IOException e){
		 * 
		 * }finally{ // close the streams } }
		 */

		/**
		 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
		 *      response)
		 */

		HttpSession se = request.getSession();
		String status1 = (String) se.getAttribute("user");
		int userid;
		if (status1.equalsIgnoreCase("admin")) {
			userid = Integer.parseInt(request.getParameter("userid"));
		} else {
			userid = (Integer) se.getAttribute("userid");
		}
		System.out.println(status1);
		System.out.println("userid1 	:" + userid);
		Userdao d = new Userdao(Dbconection.getconnect());
		User u;
		try {
			u = d.userGetById(userid);

			String Profile = u.getProfilePic();

			response.setContentType("image/jpeg");
			ServletOutputStream out;
			out = response.getOutputStream();
			FileInputStream fin = new FileInputStream(
					"C:\\Users\\shrim\\Desktop\\WorkSpace\\RegisterLoginDemo2\\src\\main\\webapp\\profile_pic\\"
							+ Profile);
			System.out.println("hello its fin:" + fin.toString());

			BufferedInputStream bin = new BufferedInputStream(fin);
			BufferedOutputStream bout = new BufferedOutputStream(out);
			int ch = 0;
			;
			while ((ch = bin.read()) != -1) {
				bout.write(ch);
			}

			bin.close();
			fin.close();
			bout.close();
			out.close();
			/* System.out.println("all close"); */

		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
