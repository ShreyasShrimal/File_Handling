package com.tech.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LogoutServlet
 */
@WebServlet("/LogoutServlet")
public class LogoutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
   
    public LogoutServlet() {
        super();
        
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		  response.setContentType("text/html");  
          PrintWriter out=response.getWriter();  
            
           
            System.out.println("hello");
          HttpSession session1 =request.getSession();  
          String status=(String) session1.getAttribute("user");
			System.out.println(" status " + status);
          session1.invalidate(); 
          System.out.println("logout Sucessfully");
          
			/*
			 * request.getRequestDispatcher("login.jsp").include(request, response);
			 */	
          HttpSession session = request.getSession();
          
			 if(status.equalsIgnoreCase("admin"))
			 { 
				 response.sendRedirect("adminlogin.jsp");
			 }
			/* session.setAttribute("succMsg", "Logout sucsessfully..."); */
			 else {
          response.sendRedirect("login.jsp");
			 }
	}

	

}
