package com.tech.servlet;


import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


@WebServlet("/downloadservlet")
public class downloadservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public downloadservlet() {
        super();
        // TODO Auto-generated constructor stub
    }
    private static final String UPLOAD_DIR = "resource";
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		        
		        String fileName =request.getParameter("filename") ;
		        System.out.println(fileName);
		        FileInputStream fileInputStream = null;
		        OutputStream responseOutputStream = null;
		        try
		        {
					/*
					 * String applicationPath = request.getServletContext().getRealPath("");
					 * 
					 * String filePath = applicationPath + File.separator + UPLOAD_DIR;
					 */
					
					  String filePath = request.getServletContext().getRealPath(UPLOAD_DIR)+File.separator+
					  fileName;
					 
		            File file = new File(filePath);
		            
		            
		            String mimeType = request.getServletContext().getMimeType(filePath);
		            if (mimeType == null) {        
		                mimeType = "application/octet-stream";
		            }
		            response.setContentType(mimeType);
		            response.addHeader("Content-Disposition", "attachment; filename=" + fileName);
		            response.setContentLength((int) file.length());
		 
		            fileInputStream = new FileInputStream(file);
		            responseOutputStream = response.getOutputStream();
		            int bytes;
		            while ((bytes = fileInputStream.read()) != -1) {
		                responseOutputStream.write(bytes);
		                
		                
		            }
		            
//		          HttpSession hs =request.getSession();
//		    		//hs.setAttribute("extension", extension);
//	    		String extension =  (String) hs.getAttribute("extension");
//	    		System.out.println("extension :"+extension);
		            
		    		//	response.sendRedirect("csvFileReading.jsp");
		    		
		    		

		    		}
		    		
		            
		        		        catch(Exception ex)
		        {
		            ex.printStackTrace();
		        }
		        finally
		        {
		            fileInputStream.close();
		            responseOutputStream.close();
		        }
		    }
		

	
	

}
