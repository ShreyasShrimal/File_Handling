package com.tech.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.tech.dao.Userdao;
import com.tech.dao.filedao;
import com.tech.helper.Dbconection;

/**
 * Servlet implementation class DeleteEmployee
 */
@WebServlet("/DeleteEmployee")
public class DeleteEmployee extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
    public DeleteEmployee() {
        super();
        // TODO Auto-generated constructor stub
    }


	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int id = Integer.parseInt(request.getParameter("userid"));
		System.out.println("delleete user id :"+id);	
		
		try {
			Userdao d = new Userdao(Dbconection.getconnect());
			boolean f = d.deleteuser(id);
			HttpSession session = request.getSession();

			if (f) {

				session.setAttribute("succMsg", "File Deleted sucsessfully...");
				response.sendRedirect("AllEmpdata.jsp");
			} else {
				session.setAttribute("errorMsg", "Somthing wrong on server...");
				response.sendRedirect("AllEmpdata.jsp");

			}
		} catch (Exception e) {

			e.printStackTrace();
		}

	}


	
	

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
